

import java.io.FileNotFoundException;
import java.io.IOException;

import org.hibernate.SessionFactory;

public class ExtDis {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		//DisassemblyParser dp = new DisassemblyParser("D:\\SRC\\Java\\extdis\\src\\vim\\exp\\func_disass.1.dis");
		
		//Repository repo = new Repository();
		
		SessionFactory hu = HibernateUtil.getSessionFactory();
		
		
	}

}

