chmod +x /home/lvr/src/Area51/dissas/out/disassemble_SomeFunctionCalls.sh
/home/lvr/src/Area51/dissas/out/disassemble_SomeFunctionCalls.sh
chmod +x /home/lvr/src/Area51/dissas/out/disassemble_vim.sh
/home/lvr/src/Area51/dissas/out/disassemble_vim.sh
