#!/bin/bash
java -jar opcenc.jar tar /home/lvr/src/opcenc/opcenc/dataexch/disassembly/tar
#/home/lvr/src/opcenc/opcenc
